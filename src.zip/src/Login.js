import React from 'react'
import {Handleronchange,Handleronclick,HandlerDelete} from './userSlice'
import {useDispatch,useSelector} from 'react-redux'
export function Login() {
    const userSelector=useSelector(state=>state.user)
    const dispatch=useDispatch()
    return (
        <div>
          <div style={{textAlign:'center'}}>
              <div style={{flexDirection:'column'}}>
              <label for="name">نام</label>
              <input id="name" type="text" name="name" onChange={(e)=>dispatch(Handleronchange(e))}/>
              </div>
              <div style={{flexDirection:'column'}}>
              <label for="family">نام خانوادکی</label>
              <input id="family" type="text" name="family" onChange={(e)=>dispatch(Handleronchange(e))}/>
              </div>
              <div style={{flexDirection:'column'}}>
              <label for="username">نام کاربری</label>
              <input id="username" type="text" name="username" onChange={(e)=>dispatch(Handleronchange(e))}/>
              </div>
              <div style={{flexDirection:'column'}}>
                  
                  <button   onClick={()=>dispatch(Handleronclick(userSelector))}>ثبت اطلاعات</button>
              </div>
              <div style={{flexDirection:'column',textAlign:'center'}}>
                  {userSelector.InFormation.map((item,index)=>{
                      if(item!==null){
                      return(
                          <table style={{textAlign:'center'}}>
                              <thead>
                                  <th>نام</th>
                                  <th>نام خانوادگی</th>
                                  <th>نام کاربری</th>
                              </thead>
                              <tbody>
                                  <td>
                                     {item.name}
                                  </td>
                                  <td>
                                     {item.family}
                                  </td>
                                  <td>
                                     {item.username}
                                  </td>
                                  <td>
                                      <button onClick={()=>dispatch(HandlerDelete(index))}>حذف</button>
                                  </td>
                              </tbody>
                          </table>
                      )}
                  })}

              </div>
          </div>
        </div>
    )
}