import {createSlice} from '@reduxjs/toolkit'
export const userSlice=createSlice({
name:'user',
initialState:{name:'',family:'',username:'',InFormation:[]},
reducers:{
    Handleronchange:(state,action)=>{
        state[action.payload.target.name]=action.payload.target.value  
        state={...state} 
    },
    Handleronclick:(state,action)=>{
        state.InFormation.push(action.payload)
        
    },
    HandlerDelete:(state,action)=>{
        state.InFormation[action.payload]=null
    }
}
})
export const {Handleronchange,Handleronclick,HandlerDelete}=userSlice.actions
export default userSlice.reducer